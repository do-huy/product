<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Voucher\\app\\Providers\\VoucherServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Voucher\\app\\Providers\\VoucherServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);