<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Bill\\app\\Providers\\BillServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Bill\\app\\Providers\\BillServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);