<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Content\\app\\Providers\\ContentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Content\\app\\Providers\\ContentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);