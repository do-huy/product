<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Cart\\app\\Providers\\CartServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Cart\\app\\Providers\\CartServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);