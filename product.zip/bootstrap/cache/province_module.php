<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Province\\app\\Providers\\ProvinceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Province\\app\\Providers\\ProvinceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);