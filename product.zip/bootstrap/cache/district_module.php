<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\District\\app\\Providers\\DistrictServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\District\\app\\Providers\\DistrictServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);