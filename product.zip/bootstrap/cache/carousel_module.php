<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Carousel\\app\\Providers\\CarouselServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Carousel\\app\\Providers\\CarouselServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);