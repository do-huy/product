<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Product\\app\\Providers\\ProductServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Product\\app\\Providers\\ProductServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);