<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Home\\app\\Providers\\HomeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Home\\app\\Providers\\HomeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);