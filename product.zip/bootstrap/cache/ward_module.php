<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Ward\\app\\Providers\\WardServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Ward\\app\\Providers\\WardServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);