<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CheckOut\\app\\Providers\\CheckOutServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CheckOut\\app\\Providers\\CheckOutServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);