<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Dashboard\\app\\Providers\\DashboardServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Dashboard\\app\\Providers\\DashboardServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);