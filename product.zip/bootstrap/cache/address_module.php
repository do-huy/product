<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Address\\app\\Providers\\AddressServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Address\\app\\Providers\\AddressServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);