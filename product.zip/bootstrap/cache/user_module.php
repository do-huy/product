<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\User\\app\\Providers\\UserServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\User\\app\\Providers\\UserServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);