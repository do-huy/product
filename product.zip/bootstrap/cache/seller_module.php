<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Seller\\app\\Providers\\SellerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Seller\\app\\Providers\\SellerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);