<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SubCategory\\app\\Providers\\SubCategoryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SubCategory\\app\\Providers\\SubCategoryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);