<?php

namespace Modules\SubCategory\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface SubCategoryRepository.
 *
 * @package namespace Modules\SubCategory\Repositories;
 */
interface SubCategoryRepository extends RepositoryInterface
{
    //
}
