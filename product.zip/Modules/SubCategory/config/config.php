<?php

return [
    'name' => 'SubCategory',
];
