<?php

return [
    'name' => 'Voucher',
];
