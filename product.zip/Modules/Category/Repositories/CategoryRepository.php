<?php

namespace Modules\Category\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CategoryRepository.
 *
 * @package namespace Modules\Category\Repositories;
 */
interface CategoryRepository extends RepositoryInterface
{
    //
}
