<?php

return [
    'name' => 'District',
];
