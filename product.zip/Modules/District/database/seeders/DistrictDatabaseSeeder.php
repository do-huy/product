<?php

namespace Modules\District\database\seeders;

use Illuminate\Database\Seeder;

class DistrictDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
