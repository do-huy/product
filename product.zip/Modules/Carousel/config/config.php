<?php

return [
    'name' => 'Carousel',
];
