<?php

namespace Modules\Carousel\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CarouselRepository.
 *
 * @package namespace Modules\Carousel\Repositories;
 */
interface CarouselRepository extends RepositoryInterface
{
    //
}
