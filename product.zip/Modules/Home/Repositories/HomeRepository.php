<?php

namespace Modules\Home\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface HomeRepository.
 *
 * @package namespace Modules\Home\Repositories;
 */
interface HomeRepository extends RepositoryInterface
{
    //
}
