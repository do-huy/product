<?php

namespace Modules\Product\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ProductRepository.
 *
 * @package namespace Modules\Product\Repositories;
 */
interface ProductRepository extends RepositoryInterface
{
    //
}
