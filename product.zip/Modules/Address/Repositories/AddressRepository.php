<?php

namespace Modules\Address\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface AddressRepository.
 *
 * @package namespace Modules\Address\Repositories;
 */
interface AddressRepository extends RepositoryInterface
{
    //
}
