<?php

namespace Modules\Address\database\seeders;

use Illuminate\Database\Seeder;

class AddressDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
