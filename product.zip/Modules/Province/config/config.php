<?php

return [
    'name' => 'Province',
];
