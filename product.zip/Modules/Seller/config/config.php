<?php

return [
    'name' => 'Seller',
];
