<?php

namespace Modules\Seller\database\seeders;

use Illuminate\Database\Seeder;

class SellerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
