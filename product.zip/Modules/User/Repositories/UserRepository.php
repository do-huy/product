<?php

namespace Modules\User\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepository.
 *
 * @package namespace Modules\User\Repositories;
 */
interface UserRepository extends RepositoryInterface
{
    //
}
