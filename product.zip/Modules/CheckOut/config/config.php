<?php

return [
    'name' => 'CheckOut',
];
